*Black* exceptions
==================

*Contents are subject to change.*

.. currentmodule:: black

.. autoexception:: black.CannotSplit

.. autoexception:: black.NothingChanged

.. autoexception:: black.InvalidInput
