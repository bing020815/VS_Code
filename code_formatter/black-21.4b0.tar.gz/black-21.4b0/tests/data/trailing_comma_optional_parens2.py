if (e123456.get_tk_patchlevel() >= (8, 6, 0, 'final') or
    (8, 5, 8) <= get_tk_patchlevel() < (8, 6)):
    pass